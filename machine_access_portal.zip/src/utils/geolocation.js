export function getCurrentPosition(options = {}) {
  return new Promise((resolve, reject) => {
    if (!('geolocation' in navigator)) {
      reject(new Error('Geolocation not supported in this browser'))
      return
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        resolve({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          timestamp: pos.timestamp
        })
      },
      (err) => {
        let msg = 'Failed to get location'
        if (err && typeof err.code !== 'undefined') {
          // Based on GeolocationPositionError codes
          if (err.code === 1) msg = 'Permission denied for location'
          if (err.code === 2) msg = 'Location unavailable'
          if (err.code === 3) msg = 'Location request timed out'
        }
        reject(new Error(msg))
      },
      options
    )
  })
}