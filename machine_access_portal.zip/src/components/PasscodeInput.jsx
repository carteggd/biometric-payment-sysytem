import React, { useMemo, useRef } from 'react'

export default function PasscodeInput({ value, onChange, length = 5, disabled = false }) {
  const inputsRef = useRef([])

  const digits = useMemo(() => {
    const v = String(value || '')
    const arr = new Array(length).fill('')
    for (let i = 0; i < Math.min(length, v.length); i++) {
      arr[i] = v[i]
    }
    return arr
  }, [value, length])

  function setFocus(index) {
    const el = inputsRef.current[index]
    if (el) el.focus()
  }

  function emit(newDigits) {
    const next = newDigits.join('')
    onChange?.(next)
  }

  function handleChange(idx, e) {
    const raw = e.target.value
    const onlyDigits = raw.replace(/\D/g, '')
    if (onlyDigits.length === 0) {
      // cleared this box
      const nd = [...digits]
      nd[idx] = ''
      emit(nd)
      return
    }

    // Support paste of multiple digits into one box
    const chars = onlyDigits.split('')
    const nd = [...digits]
    let cursor = idx
    for (let c of chars) {
      if (cursor >= length) break
      nd[cursor] = c
      cursor++
    }
    emit(nd)
    // Move focus to next available cell
    if (idx + chars.length < length) {
      setFocus(idx + chars.length)
    }
  }

  function handleKeyDown(idx, e) {
    if (e.key === 'Backspace') {
      if (digits[idx]) {
        // delete current digit
        const nd = [...digits]
        nd[idx] = ''
        emit(nd)
      } else if (idx > 0) {
        setFocus(idx - 1)
        const nd = [...digits]
        nd[idx - 1] = ''
        emit(nd)
      }
      e.preventDefault()
    } else if (e.key === 'ArrowLeft') {
      if (idx > 0) setFocus(idx - 1)
      e.preventDefault()
    } else if (e.key === 'ArrowRight') {
      if (idx < length - 1) setFocus(idx + 1)
      e.preventDefault()
    }
  }

  function handlePaste(idx, e) {
    const text = e.clipboardData.getData('text') || ''
    const onlyDigits = text.replace(/\D/g, '')
    if (!onlyDigits) return
    e.preventDefault()
    const nd = [...digits]
    let cursor = idx
    for (let i = 0; i < onlyDigits.length; i++) {
      if (cursor >= length) break
      nd[cursor] = onlyDigits[i]
      cursor++
    }
    emit(nd)
    if (cursor < length) setFocus(cursor)
  }

  return (
    <div className="passcode">
      {digits.map((d, i) => (
        <input
          key={i}
          ref={el => (inputsRef.current[i] = el)}
          className="digit"
          type="password"
          inputMode="numeric"
          pattern="[0-9]*"
          maxLength={1}
          value={d}
          onChange={e => handleChange(i, e)}
          onKeyDown={e => handleKeyDown(i, e)}
          onPaste={e => handlePaste(i, e)}
          disabled={disabled}
          aria-label={`Digit ${i + 1} of ${length}`}
        />
      ))}
    </div>
  )
}