import React from 'react'

export default function NeonBackground() {
  return (
    <div className="neon-bg" aria-hidden="true">
      <div className="neon-grid"></div>
      <div className="blob blob1"></div>
      <div className="blob blob2"></div>
      <div className="blob blob3"></div>
      <div className="edge-glow"></div>
    </div>
  )
}