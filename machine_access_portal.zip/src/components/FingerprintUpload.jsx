import React, { useEffect, useMemo, useRef, useState } from 'react'

const ACCEPT = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'application/pdf']
const MAX_SIZE_BYTES = 10 * 1024 * 1024 // 10MB

export default function FingerprintUpload({ file, onChange }) {
  const inputRef = useRef(null)
  const [error, setError] = useState('')
  const [previewUrl, setPreviewUrl] = useState('')

  useEffect(() => {
    if (file && file.type.startsWith('image/')) {
      const url = URL.createObjectURL(file)
      setPreviewUrl(url)
      return () => URL.revokeObjectURL(url)
    } else {
      setPreviewUrl('')
    }
  }, [file])

  function validateFile(f) {
    if (!f) return 'No file selected'
    if (!ACCEPT.includes(f.type)) return 'Unsupported file type. Use image or PDF.'
    if (f.size > MAX_SIZE_BYTES) return 'File too large (max 10MB).'
    return ''
  }

  function selectFile(f) {
    const err = validateFile(f)
    setError(err)
    if (err) {
      onChange?.(null)
      return
    }
    onChange?.(f)
  }

  function handleInputChange(e) {
    const f = e.target.files?.[0]
    if (f) selectFile(f)
  }

  function handleDrop(e) {
    e.preventDefault()
    const f = e.dataTransfer.files?.[0]
    if (f) selectFile(f)
  }

  function handleDragOver(e) {
    e.preventDefault()
  }

  return (
    <div className="upload">
      <div
        className="dropzone"
        onClick={() => inputRef.current?.click()}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        role="button"
        tabIndex={0}
      >
        {!file ? (
          <div className="dropContent">
            <div className="dropTitle">Click to upload or drag &amp; drop</div>
            <div className="dropSub">PNG, JPG, or PDF</div>
          </div>
        ) : (
          <div className="filePreview">
            {previewUrl ? (
              <img src={previewUrl} alt="Fingerprint preview" className="previewImg" />
            ) : (
              <div className="fileRow">
                <span className="fileName">{file.name}</span>
                <span className="fileMeta">{file.type || 'file'} · {Math.round(file.size / 1024)} KB</span>
              </div>
            )}
            <button
              type="button"
              className="btn"
              onClick={(e) => {
                e.stopPropagation()
                onChange?.(null)
                setError('')
              }}
            >
              Remove
            </button>
          </div>
        )}
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT.join(',')}
          onChange={handleInputChange}
          style={{ display: 'none' }}
        />
      </div>
      {error && <p className="hint error">{error}</p>}
    </div>
  )
}