import React, { useEffect, useMemo, useState } from 'react'
import PasscodeInput from './components/PasscodeInput.jsx'
import FingerprintUpload from './components/FingerprintUpload.jsx'
import { getCurrentPosition } from './utils/geolocation.js'
import NeonBackground from './components/NeonBackground.jsx'

export default function App() {
  const [passcode, setPasscode] = useState('')
  const [fingerprintFile, setFingerprintFile] = useState(null)
  const [location, setLocation] = useState(null)
  const [locError, setLocError] = useState('')
  const [locLoading, setLocLoading] = useState(false)
  const [submitLoading, setSubmitLoading] = useState(false)
  const [submittedData, setSubmittedData] = useState(null)

  const [amount, setAmount] = useState('')
  const [merchant, setMerchant] = useState('')

  const isPasscodeValid = useMemo(() => /^\d{5}$/.test(passcode), [passcode])
  const isFingerprintReady = useMemo(() => !!fingerprintFile, [fingerprintFile])
  const isAmountValid = useMemo(() => {
    const v = parseFloat(amount)
    return !Number.isNaN(v) && v > 0
  }, [amount])
  const isMerchantValid = useMemo(() => merchant.trim().length > 0, [merchant])

  // IMPORTANT: Do not require location before enabling submit.
  const canSubmit =
    isPasscodeValid &&
    isFingerprintReady &&
    isAmountValid &&
    isMerchantValid

  useEffect(() => {
    // Optional: try to fetch on mount; user will be prompted on first interaction anyway.
    fetchLocation()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function fetchLocation() {
    setLocLoading(true)
    setLocError('')
    try {
      const pos = await getCurrentPosition({
        enableHighAccuracy: true,
        maximumAge: 10000,
        timeout: 10000
      })
      setLocation(pos)
      return pos
    } catch (err) {
      setLocError(err?.message || 'Failed to get location')
      setLocation(null)
      return null
    } finally {
      setLocLoading(false)
    }
  }

  async function handleSubmit(e) {
    e.preventDefault()
    if (!canSubmit) return

    setSubmitLoading(true)
    setLocError('')

    // Always attempt to fetch latest location on submit
    let pos = null
    try {
      setLocLoading(true)
      pos = await getCurrentPosition({
        enableHighAccuracy: true,
        maximumAge: 5000,
        timeout: 10000
      })
      setLocation(pos)
    } catch (err) {
      // If fetching fails, keep going but record the error and use existing location if any
      setLocError(err?.message || 'Failed to get location')
      pos = location || null
    } finally {
      setLocLoading(false)
    }

    const payload = {
      merchant: merchant.trim(),
      amount: parseFloat(amount),
      passcode,
      fingerprint: fingerprintFile
        ? {
            name: fingerprintFile.name,
            type: fingerprintFile.type,
            size: fingerprintFile.size
          }
        : null,
      location: pos
    }

    // Avoid logging raw passcode
    console.log('Submitting payload:', { ...payload, passcode: '*****' })
    setSubmittedData(payload)
    setSubmitLoading(false)
  }

  return (
    <>
      <NeonBackground />
      <div className="app">
        <header className="header">
          <h1>Biometric Payment</h1>
          <p className="subtitle">
            Enter payment details, 5-digit passcode, upload fingerprint, fetch location, then submit.
          </p>
        </header>

        <main className="container">
          <form className="card" onSubmit={handleSubmit}>
            <section className="section">
              <label className="label">Payment Details</label>
              <div className="fieldsRow">
                <div className="field">
                  <div className="smallLabel">Amount</div>
                  <input
                    className="input"
                    type="number"
                    inputMode="decimal"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    aria-invalid={amount.length > 0 && !isAmountValid}
                  />
                  {amount.length > 0 && !isAmountValid && (
                    <p className="hint error">Enter a valid amount greater than 0.</p>
                  )}
                </div>
                <div className="field">
                  <div className="smallLabel">Merchant</div>
                  <input
                    className="input"
                    type="text"
                    placeholder="Merchant name"
                    value={merchant}
                    onChange={e => setMerchant(e.target.value)}
                    aria-invalid={merchant.length > 0 && !isMerchantValid}
                  />
                  {merchant.length > 0 && !isMerchantValid && (
                    <p className="hint error">Merchant is required.</p>
                  )}
                </div>
              </div>
            </section>

            <section className="section">
              <label className="label">5-Digit Passcode</label>
              <PasscodeInput value={passcode} onChange={setPasscode} length={5} />
              {!isPasscodeValid && passcode.length > 0 && (
                <p className="hint error">Passcode must be exactly 5 digits.</p>
              )}
            </section>

            <section className="section">
              <label className="label">Fingerprint Upload</label>
              <FingerprintUpload file={fingerprintFile} onChange={setFingerprintFile} />
              {!isFingerprintReady && (
                <p className="hint">Accepted: images (PNG/JPG) or PDF. Max ~10MB recommended.</p>
              )}
            </section>

            <section className="section">
              <label className="label">Location</label>
              <div className="locationRow">
                <button
                  type="button"
                  className="btn"
                  onClick={fetchLocation}
                  disabled={locLoading}
                  aria-busy={locLoading ? 'true' : 'false'}
                >
                  {locLoading ? 'Fetching location...' : 'Fetch location'}
                </button>
                {location ? (
                  <div className="locStatus">
                    <span className="badge success">Captured</span>
                    <span className="coords">
                      Lat: {location.lat.toFixed(6)}, Lng: {location.lng.toFixed(6)}
                      {typeof location.accuracy === 'number' ? ` (±${Math.round(location.accuracy)} m)` : ''}
                    </span>
                  </div>
                ) : (
                  <div className="locStatus">
                    <span className="badge">Not captured</span>
                    <span className="coords muted">Will auto-fetch on submit (HTTPS or localhost)</span>
                  </div>
                )}
              </div>
              {locError && <p className="hint error">{locError}</p>}
            </section>

            <div className="actions">
              <button
                type="submit"
                className="btn primary"
                disabled={!canSubmit || submitLoading}
                aria-busy={submitLoading ? 'true' : 'false'}
              >
                {submitLoading ? 'Submitting...' : 'Submit'}
              </button>
            </div>
          </form>

          {submittedData && (
            <div className="card output">
              <h2>Submission Preview</h2>
              <div className="grid">
                <div>
                  <div className="smallLabel">Merchant</div>
                  <div className="mono">{submittedData.merchant}</div>
                </div>
                <div>
                  <div className="smallLabel">Amount</div>
                  <div className="mono">{submittedData.amount.toFixed(2)}</div>
                </div>
                <div>
                  <div className="smallLabel">Passcode</div>
                  <div className="mono">{'•'.repeat(submittedData.passcode.length)}</div>
                </div>
                <div>
                  <div className="smallLabel">Fingerprint</div>
                  <div className="mono">
                    {submittedData.fingerprint
                      ? `${submittedData.fingerprint.name} (${submittedData.fingerprint.type || 'unknown'}, ${Math.round(
                          submittedData.fingerprint.size / 1024
                        )} KB)`
                      : 'None'}
                  </div>
                </div>
                <div>
                  <div className="smallLabel">Location</div>
                  <div className="mono">
                    {submittedData.location
                      ? `lat=${submittedData.location.lat}, lng=${submittedData.location.lng}, acc=${submittedData.location.accuracy ?? 'n/a'}`
                      : 'None'}
                  </div>
                </div>
              </div>
              <p className="hint">Note: This demo only shows data locally in the browser console and UI.</p>
            </div>
          )}
        </main>

        <footer className="footer">
          <p>Geolocation works on HTTPS or localhost. Your files are not uploaded anywhere in this demo.</p>
        </footer>
      </div>
    </>
  )
}